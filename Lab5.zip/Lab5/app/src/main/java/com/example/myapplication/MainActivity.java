package com.example.myapplication;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.media.Image;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import org.w3c.dom.Text;

public class MainActivity extends Activity {

    private ListView listaMasini;
    CarAdapter carAdapter;
    private EditText adaugaMasina;
    private Button adaugaButton;
    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listaMasini = findViewById(R.id.lv_list_cars);
        carAdapter = new CarAdapter(MainActivity.this);
        listaMasini.setAdapter(carAdapter);
        carAdapter.addCar("Volkswagen", R.drawable.lab5_car_icon);
        carAdapter.addCar("Audi", R.drawable.lab5_car_icon);
        carAdapter.addCar("BMW", R.drawable.lab5_car_icon);
        carAdapter.addCar("Porsche", R.drawable.lab5_car_icon);
        adaugaMasina = findViewById(R.id.ed_new_car);
        adaugaButton = findViewById(R.id.b_add_car);

        adaugaButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                String nume = adaugaMasina.getText().toString();
                int imagine = R.drawable.lab5_car_icon;

                carAdapter.addCar(nume, imagine);
                adaugaMasina.setText("");
            }
        });
    }
class Car {
    String name;
    int imageResource;
}

class TagCar {
    TextView name;
    ImageView image;
}
}